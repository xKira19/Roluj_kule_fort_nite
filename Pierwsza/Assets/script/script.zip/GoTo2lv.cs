﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoTo2lv : MonoBehaviour
{

    void OnMouseDown()
    {
        Application.LoadLevel("druga");
    }
}