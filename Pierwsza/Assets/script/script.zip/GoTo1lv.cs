﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoTo1lv : MonoBehaviour {

    void OnMouseDown()
    {
        Application.LoadLevel("pierwsza");    
    }
}
